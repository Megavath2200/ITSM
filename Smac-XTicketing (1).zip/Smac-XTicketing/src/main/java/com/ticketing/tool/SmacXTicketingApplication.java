package com.ticketing.tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmacXTicketingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmacXTicketingApplication.class, args);
	}

}
