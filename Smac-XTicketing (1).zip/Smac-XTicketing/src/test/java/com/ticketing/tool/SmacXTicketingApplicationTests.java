package com.ticketing.tool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmacXTicketingApplicationTests {

	@Test
	void contextLoads() {
	}

}
